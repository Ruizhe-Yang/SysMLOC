package dut.control.sysmloc.cli;

import com.google.inject.Injector;
import org.eclipse.emf.common.util.URI;
import org.eclipse.emf.ecore.resource.Resource;
import org.eclipse.xtext.resource.XtextResourceSet;
import org.eclipse.xtext.util.CancelIndicator;
import org.eclipse.xtext.validation.CheckMode;
import org.eclipse.xtext.validation.IResourceValidator;
import org.eclipse.xtext.validation.Issue;

import java.io.ByteArrayInputStream;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;

public class Main {
    public static void main(String[] args) throws Exception {
        if (args.length != 1) {
            System.err.println("Usage: java -jar sysmloc-cli-*-all.jar <path-to-dsl-file>");
            System.exit(2);
        }

        Path file = Path.of(args[0]).toAbsolutePath();
        String text = Files.readString(file);

        Injector injector = new dut.control.sysmloc.SysMLOCStandaloneSetup()
                .createInjectorAndDoEMFRegistration();

        XtextResourceSet rs = injector.getInstance(XtextResourceSet.class);
        Resource r = rs.createResource(URI.createFileURI(file.toString()));
        r.load(new ByteArrayInputStream(text.getBytes(StandardCharsets.UTF_8)), rs.getLoadOptions());

        IResourceValidator v = injector.getInstance(IResourceValidator.class);
        List<Issue> issues = v.validate(r, CheckMode.ALL, CancelIndicator.NullImpl);

        System.out.println("Issues: " + issues.size());
        for (Issue i : issues) System.out.println(i);

        System.exit(issues.isEmpty() ? 0 : 1);
    }
}
